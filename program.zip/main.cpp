#include <iostream>
#include <conio.h>
#include <Windows.h>
#include <string>
#include <stdlib.h>

#include <mysql_connection.h>

#include<cppconn\driver.h>
#include<cppconn\exception.h>
#include<cppconn\resultset.h>
#include<cppconn\statement.h>
#include<cppconn\prepared_statement.h>

//name spaces
using namespace std;

//global variables
bool stop = false;
/*
sql::Driver *driver;
sql::Connection *con;
sql::Statement *stmt;
sql::ResultSet *res;
*/

/*
		win height=22,
		width=80,
		font size=28
*/

//functions prediefine
void mainMenu();
void gotoxy(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void selectallbook();
void selectallmembers();
void del(string, int);
void update(string, string a[], int b[]);
void insert(string,string a[],int b[]);


//class
class books
{
protected:
	char title[45], author[30], publisher[30];
	int cost,qty,code;

public:
	void addBook();
	void listBooks();
	void searchBook();
	void editBook();
	void deleteBook();

} book;

class members
{
protected:
	char fname[30],lname[20],address[30];
	int fine, code,issued;
	long int contact;

public:
	void addMember();
	void listMembers();
	void searchMember();
	void editMember();
	void deleteMember();
} member;

class transact: protected members, protected books
{
	int bookC, memberC;
public:
	void issueBook();
	void returnBook();
} trans;


void transact::issueBook()
{
	system("cls");
	gotoxy(25, 5);	 cout << "----------Issue Book----------";
	gotoxy(15, 10);  cout << "Enter code of Book to issue: ";
	cin >> bookC;
	gotoxy(15, 11);  cout << "Enter code of Member: ";
	cin >> memberC;


	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		sql::ResultSet *res,*mres;
		sql::PreparedStatement *pstmt,*mpstmt,*rpstmt,*bookup,*memberup,*rec;
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		//stmt = con->createStatement();

		pstmt = con->prepareStatement("SELECT qty,issue FROM books WHERE code=?");
		pstmt->setInt(1, bookC);
		int qt=0, iss=0,m_iss=0;
		mpstmt = con->prepareStatement("SELECT issued FROM members WHERE code=?");
		mpstmt->setInt(1, memberC);

		//cout <<"\n Retrieved Rows : " << res->rowsCount() << endl;
		//res=stmt->execute();

		res = pstmt->executeQuery();
		mres = mpstmt->executeQuery();
		if (res->next())
		{
			if (mres->next())
			{
				qt = res->getInt("qty");
				iss = res->getInt("issue");

				m_iss = mres->getInt("issued");

				if (qt - iss > 0)
				{
					iss = iss + 1;
					if (m_iss < 3)
					{
						m_iss = m_iss + 1;
						memberup = con->prepareStatement("UPDATE members SET issued=? WHERE code=?");
						memberup->setInt(1, m_iss);
						memberup->setInt(2, memberC);
						memberup->executeUpdate();

						bookup = con->prepareStatement("UPDATE books SET issue=? WHERE code=?");
						bookup->setInt(1, iss);
						bookup->setInt(2, bookC);
						bookup->executeUpdate();

						rpstmt = con->prepareStatement("INSERT INTO record VALUES(?,?)");
						rpstmt->setInt(1, bookC);
						rpstmt->setInt(2, memberC);
						rpstmt->execute();
						cout << "Issued";
					}
					else
					{
						cout << "Already issued 3 books!";
					}
				}
				else
				{
					cout << "Books not avaliable";
				}
			}
			else
			{
				cout << "Member Code not avaliable!";
			}
		}
		else
		{
			cout << "Book Code not avaliable!";
		}
		delete pstmt, mpstmt, bookup, memberup, rec;
		delete res, mres;
		//delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}

}

void transact::returnBook()
{
	system("cls");
	gotoxy(25, 5);	 cout << "----------Return Book----------";
	gotoxy(15, 10);  cout << "Enter code of Book to return: ";
	cin >> bookC;
	gotoxy(15, 11);  cout << "Enter code of Member: ";
	cin >> memberC;


	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		sql::ResultSet *res, *mres;
		sql::PreparedStatement *pstmt, *mpstmt, *rpstmt, *bookup, *memberup, *rec;
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		//stmt = con->createStatement();

		pstmt = con->prepareStatement("SELECT issue FROM books WHERE code=?");
		pstmt->setInt(1, bookC);
		int qt = 0, iss = 0, m_iss = 0;
		mpstmt = con->prepareStatement("SELECT issued FROM members WHERE code=?");
		mpstmt->setInt(1, memberC);

		//cout <<"\n Retrieved Rows : " << res->rowsCount() << endl;
		//res=stmt->execute();

		res = pstmt->executeQuery();
		mres = mpstmt->executeQuery();
		if (res->next())
		{
			if (mres->next())
			{
				iss = res->getInt("issue");

				m_iss = mres->getInt("issued");

				if (iss > 0)
				{
					iss = iss - 1;
					if (m_iss > 0)
					{
						m_iss = m_iss - 1;
						memberup = con->prepareStatement("UPDATE members SET issued=? WHERE code=?");
						memberup->setInt(1, m_iss);
						memberup->setInt(2, memberC);
						memberup->executeUpdate();

						bookup = con->prepareStatement("UPDATE books SET issue=? WHERE code=?");
						bookup->setInt(1, iss);
						bookup->setInt(2, bookC);
						bookup->executeUpdate();

						rpstmt = con->prepareStatement("DELETE FROM record WHERE book=? AND member=?");
						rpstmt->setInt(1, bookC);
						rpstmt->setInt(2, memberC);
						rpstmt->execute();
						cout << "Returned";
					}
					else
					{
						cout << "The member haven't issued the book!";
					}
				}
				else
				{
					cout << "The books wasn't issued!";
				}
			}
			else
			{
				cout << "Member Code not avaliable!";
			}
		}
		else
		{
			cout << "Book Code not avaliable!";
		}
		delete pstmt, mpstmt, bookup, memberup, rec;
		delete res, mres;
		//delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}

}








//books

void books::listBooks()
{

	system("cls");
	gotoxy(25, 1);	cout << "<<----- List of Books ----->>" << endl;
	gotoxy(33, 2);	cout << "-------------" << endl;

	gotoxy(0, 3);	cout << "S.N." << endl;
	gotoxy(6, 3);	cout << "Title" << endl;
	gotoxy(38, 3);	cout << "Author" << endl;
	gotoxy(60, 3);	cout << "Avaliable" << endl;
	gotoxy(75, 3);	cout << "Code" << endl;
	gotoxy(0, 4); cout << "-------------------------------------------------------------------------------";

	selectallbook();
}


void books::addBook()
{
		system("cls");
		gotoxy(33, 1);	cout << "Add New Book" << endl;
		gotoxy(33, 2);	cout << "--------------" << endl;
		fflush(stdin);
		gotoxy(15,4);		cout << "Enter title of book: ";
		//cin >> book.title;
		//gets(book.title);
		cin.getline(book.title,45);
		gotoxy(15, 5); 		cout << "Enter author name: ";
		cin.getline(book.author, 30);
		//cin >> book.author;
		gotoxy(15, 6);		cout << "Enter publisher name: ";
		cin.getline(book.publisher, 30);
		//cin >> book.publisher;
		gotoxy(15, 7);		cout << "Enter cost of book: ";
		cin >> book.cost;
		gotoxy(15, 8);		cout << "Enter quantity of books: ";
		cin >> book.qty;
		gotoxy(15, 9);		cout << "Enter code of books: ";
		cin >> book.code;

		string a[] = { book.title, book.author, book.publisher };
		int b[] = { book.cost, book.qty ,book.code ,0};
		insert("INSERT INTO books VALUES(? , ? , ? , ? , ? , ?, ? )", a, b);

}

void books::searchBook()
{
	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		sql::ResultSet *res;
		sql::PreparedStatement *pstmt;
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		//stmt = con->createStatement();

		int key;
		system("cls");


		gotoxy(25, 5);	 cout << "----------Search Book----------";
		gotoxy(25, 10);	 cout << "Enter code of book to search: ";
		cin >> key;
		system("cls");
		gotoxy(25, 5);	 cout << "----------Book Detail----------";
		pstmt = con->prepareStatement("SELECT title, author, qty, code, issue FROM books WHERE code=?");
		pstmt->setInt(1, key);

		res = pstmt->executeQuery();
		//cout <<"\n Retrieved Rows : " << res->rowsCount() << endl;
		//res=stmt->execute();
		if (res->next())
		{

			gotoxy(25, 7);		cout << "Title: ";				gotoxy(40, 7);	cout << res->getString("title");
			gotoxy(25, 8);		cout << "Book code: ";			gotoxy(40, 8);	cout << res->getInt("code");
			gotoxy(25, 9);		cout << "Author: ";				gotoxy(40, 9);	cout << res->getString("author");
			gotoxy(25, 10);		cout << "Quantity: ";			gotoxy(40, 10);	cout << res->getInt("qty");
			gotoxy(25, 11);		cout << "Issued: ";				gotoxy(40, 11);	cout << res->getInt("issue");
			gotoxy(25, 12);		cout << "Avaliabe: ";			gotoxy(40, 12);	cout << res->getInt("qty") - res->getInt("issue");
		}
		delete pstmt;
		delete res;
		//delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}
}

void books::editBook()
{
	system("cls");
	gotoxy(30, 1);	cout << "Update Book" << endl;
	gotoxy(30, 2);	cout << "--------------" << endl;
	gotoxy(15, 4); cout << "Enter code of book to edit: ";
	cin >> code;
	gotoxy(15, 6); cout << "Enter title of book: ";
	cin >> title;
	gotoxy(15, 7); cout << "Enter author name: ";
	cin >> author;
	gotoxy(15, 8); cout << "Enter publisher name: ";
	cin >> publisher;
	gotoxy(15, 9); cout << "Enter cost of book: ";
	cin >> cost;
	gotoxy(15, 10); cout << "Enter quantity of books: ";
	cin >> qty;

	string a[] = { book.title, book.author, book.publisher };
	int b[] = { book.cost, book.qty ,book.code };
	
	update("UPDATE books SET title = ?,author=?,publisher=?,cost=?, qty=? WHERE code=?", a, b);
}

void books::deleteBook()
{
	system("cls");
	gotoxy(30, 1);	cout << "Delete Book" << endl;
	gotoxy(30, 2);	cout << "--------------" << endl;
	gotoxy(15, 10); cout << "Enter code of book to delete: ";
	cin >> code;
	
	del("DELETE FROM books WHERE code=?",code);
}

void bookMenu()
{
	char key;
	system("cls");
	gotoxy(15, 4);	cout << "<<||============= Books Menu =============||>>" << endl;
	gotoxy(30, 6);	cout << "1. (L)ist of books" << endl;
	gotoxy(30, 7);	cout << "2. (A)dd new book" << endl;
	gotoxy(30, 8);	cout << "3. (S)earch book" << endl;
	gotoxy(30, 9);	cout << "4. (E)dit book detail" << endl;
	gotoxy(30, 10);	cout << "5. (D)elete book" << endl;
	gotoxy(30, 11);	cout << "6. Back to (M)ain Menu" << endl;

	gotoxy(26, 13); cout << "Press any option(1-5): ";
	key = _getch();
	switch (key)
	{
	case '1':
	case 'l':
	case 'L':
	{
		book.listBooks();
		break;
	}
	case '2':
	case 'a':
	case 'A':
	{
		book.addBook();
		break;
	}
	case '3':
	case 's':
	case 'S':
	{
		book.searchBook();
		break;
	}

	case '4':
	case 'e':
	case 'E':
	{
		book.editBook();
		break;
	}
	case '5':
	case 'd':
	case 'D':
	{
		book.deleteBook();
		break;
	}
	case '6':
	case 'm':
	case 'M':
	{
		mainMenu();
		break;
	}
	default:
	{
		system("cls");
		gotoxy(20, 9);		cout << "Error! Please select correct number..." << endl;
		fflush(stdin);
		key = '\0';
		gotoxy(22, 11);		system("pause");
	}
	}

}






//members


void members::listMembers()
{
	system("cls");
	gotoxy(25, 1);	cout << "<<----- List of Members ----->>" << endl;
	gotoxy(33, 2);	cout << "-------------" << endl;

	gotoxy(0, 3);	cout << "S.N." << endl;
	gotoxy(5, 3);	cout << "First name" << endl;
	gotoxy(20, 3);	cout << "Last Name" << endl;
	gotoxy(35, 3);	cout << "Address" << endl;
	gotoxy(50, 3);	cout << "Contact No." << endl;
	gotoxy(67, 3);	cout << "Books" << endl;
	gotoxy(75, 3);	cout << "Code" << endl;
	gotoxy(0, 4); cout << "-------------------------------------------------------------------------------";

	selectallmembers();
}

void members::addMember()
{
	system("cls");
	fflush(stdin);
	gotoxy(33, 1);	cout << "Add New Member" << endl;
	gotoxy(33, 2);	cout << "--------------" << endl;
	gotoxy(15, 6);		cout << "Enter first name: ";
	cin >> member.fname;
	gotoxy(15, 7); 		cout << "Enter last name: ";
	cin >> member.lname;
	gotoxy(15, 8); 		cout << "Enter address: ";
	cin >> member.address;
	gotoxy(15, 9); 		cout << "Enter contact number: ";
	cin >> member.contact;

	member.issued = 0;
	member.fine = 0;

	gotoxy(15, 10);		cout << "Enter code of member: ";
	cin >> member.code;
	string a[] = { member.fname, member.lname, member.address };
	int b[] = {member.contact, member.issued, member.fine ,member.code };
	insert("INSERT INTO members VALUES(? , ? , ? , ? , ? , ?, ? )", a, b);

	//store
}

void members::searchMember()
{
	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		sql::ResultSet *res;
		sql::PreparedStatement *pstmt;
		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		//stmt = con->createStatement();

		int key;
		system("cls");


		gotoxy(25, 5);	 cout << "----------Search Member----------";
		gotoxy(25, 10);	 cout << "Enter code of member to search: ";
		cin >> key;
		system("cls");
		gotoxy(25, 5);	 cout << "----------Member Detail----------";
		pstmt = con->prepareStatement("SELECT * FROM members WHERE code=?");
		pstmt->setInt(1, key);

		res = pstmt->executeQuery();
		//cout <<"\n Retrieved Rows : " << res->rowsCount() << endl;
		//res=stmt->execute();
		if (res->next())
		{

			gotoxy(25, 7);		cout << "First name: ";				gotoxy(40, 7);	cout << res->getString("fname");
			gotoxy(25, 8);		cout << "Last name: ";			gotoxy(40, 8);	cout << res->getString("lname");
			gotoxy(25, 9);		cout << "Address: ";				gotoxy(40, 9);	cout << res->getString("address");
			gotoxy(25, 10);		cout << "Contact No.: ";			gotoxy(40, 10);	cout << res->getInt("contact");
			gotoxy(25, 11);		cout << "Books Issued: ";				gotoxy(40, 11);	cout << res->getInt("issued");
			gotoxy(25, 12);		cout << "Code: ";			gotoxy(40, 12);	cout << res->getInt("code");
		}
		delete pstmt;
		delete res;
		//delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}

}

void members::editMember()
{
	system("cls");
	gotoxy(30, 1);	cout << "Update Member details" << endl;
	gotoxy(30, 2);	cout << "--------------" << endl;
	gotoxy(15, 4); cout << "Enter code of member to edit: ";
	cin >> code;
	gotoxy(15, 6); cout << "Enter first name: ";
	cin >> fname;
	gotoxy(15, 7); cout << "Enter last name: ";
	cin >> lname;
	gotoxy(15, 8); cout << "Enter address: ";
	cin >> address;
	gotoxy(15, 9); cout << "Enter contact number: ";
	cin >> contact;

	string a[] = { fname,lname,address};
	int b[] = { contact, fine ,code};

	update("UPDATE members SET fname = ?,lname=?,address=?,contact=?, fine=? WHERE code=?", a, b);
}

void members::deleteMember()
{
	system("cls");
	gotoxy(30, 1);	cout << "Delete Book" << endl;
	gotoxy(30, 2);	cout << "--------------" << endl;
	gotoxy(15, 10); cout << "Enter code of member to delete: ";
	cin >> code;

	del("DELETE FROM members WHERE code=?", code);
}


void memberMenu()
{
	char key;
	system("cls");
	gotoxy(15, 4);	cout << "<<||============= Members Menu =============||>>" << endl;
	gotoxy(30, 6);	cout << "1. (L)ist of members" << endl;
	gotoxy(30, 7);	cout << "2. (A)dd new member" << endl;
	gotoxy(30, 8);	cout << "3. (S)earch member" << endl;
	gotoxy(30, 9);	cout << "4. (E)dit member detail" << endl;
	gotoxy(30, 10); cout << "5. (D)elete member" << endl;
	gotoxy(30, 11); cout << "6. Back to (M)ain Menu" << endl;

	gotoxy(26, 13); cout << "Press any option(1-6): ";
	key = _getch();
	switch (key)
	{
	case '1':
	case 'l':
	case 'L':
	{
		member.listMembers();
		break;
	}
	case '2':
	case 'a':
	case 'A':
	{
		member.addMember();
		break;
	}
	case '3':
	case 's':
	case 'S':
	{
		member.searchMember();
		break;
	}
	case '4':
	case 'e':
	case 'E':
	{
		member.editMember();
		break;
	}
	case '5':
	case 'd':
	case 'D':
	{
		member.deleteMember();
		break;
	}
	case '6':
	case 'm':
	case 'M':
	{
		mainMenu();
	}
	default:
	{
		system("cls");
		gotoxy(20, 9);		cout << "Error! Please select correct number..." << endl;
		fflush(stdin);
		key = '\0';
		gotoxy(22, 11);		system("pause");
	}
	}
}



//about program
void about()
{
	system("cls");
	system("type about.txt");
	system("pause");
}



//main menu
void mainMenu()
{
	system("cls");
	char key;
	gotoxy(15, 4);	cout << "<<||============= Main Menu =============||>>" << endl;
	// left
	for (int i = 0; i <= 10; i++)
	{
		gotoxy(20, 5 + i);	cout << "|";
	}
	// right
	for (int i = 0; i <= 10; i++)
	{
		gotoxy(54, 5 + i);	cout << "|";
	}
	// bottom
	for (int i = 0; i <= 34; i++)
	{
		gotoxy(20 + i, 15);	cout << "~";
	}
	gotoxy(30,6);	cout << "1. (I)ssue a book" << endl;
	gotoxy(30,7);	cout << "2. (R)eturn book" << endl;
	gotoxy(30,8);	cout << "3. (B)ooks menu" << endl;
	gotoxy(30,9);	cout << "4. (M)embers menu" << endl;
	gotoxy(30,10);	cout << "5. (A)bout" << endl;
	gotoxy(30,11);	cout << "6. (E)xit"<< endl;

	gotoxy(26, 13);	cout << "Press any option(1-6): ";
	//cin >> key;
	key = _getch();

	switch (key)
	{
	case '1':
	case 'i':
	case 'I':
	{
		trans.issueBook();
		break;
	}
	case '2':
	case 'r':
	case 'R':
	{
		trans.returnBook();
		break;
	}
	case '3':
	case 'b':
	case 'B':
	{
		bookMenu();
		break;
	}
	case '4':
	case 'm':
	case 'M':
	{
		memberMenu();
		break;
	}
	case '5':
	case 'a':
	case 'A':
	{
		about();
		break;
	}
	case '6':
	case 'e':
	case 'E':
	{
		stop = true;
		break;
	}
	default:
	{
		system("cls");
		gotoxy(20, 9);		cout << "Error! Please select correct number..."<<endl;
		fflush(stdin);
		key = '\0';
		gotoxy(22, 11);		system("pause");
		//break;
	}
	}
}



//sql

void selectallbook()
{
	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		sql::ResultSet *res;

		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		stmt = con->createStatement();

		res = stmt->executeQuery("SELECT * FROM books");

		int i = 0;
		while (res->next())
		{
			gotoxy(1, 5 + i); cout << i + 1;
			gotoxy(6, 5 + i);	cout << res->getString("title");
			gotoxy(38, 5 + i);   cout << res->getString("author");
			gotoxy(63, 5 + i);   cout << res->getInt("qty")-res->getInt("issue");
			gotoxy(75, 5 + i);   cout << res->getInt("code");
			i++;
		}
		delete res;
		delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}
}


void selectallmembers()
{

	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		sql::ResultSet *res;

		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		stmt = con->createStatement();

		res = stmt->executeQuery("SELECT * FROM members");

		int i = 0;
		while (res->next())
		{
			gotoxy(1, 5 + i); cout << i + 1;
			gotoxy(5, 5 + i);	cout << res->getString("fname");
			gotoxy(20, 5 + i);   cout << res->getString("lname");
			gotoxy(35, 5 + i);	cout << res->getString("address");
			gotoxy(50, 5 + i);   cout << res->getInt("contact");
			gotoxy(69, 5 + i);   cout << res->getInt("issued");
			gotoxy(75, 5 + i);   cout << res->getInt("code");
			i++;
		}
		delete res;
		delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}
}

//void insert(string sqlquary,string[] value)
//void insert(sql::PreparedStatement  *pstmt)
void insert(string sqlquary, string str[],int in[])
{
	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		//sql::ResultSet *res;

		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		stmt = con->createStatement();



		sql::PreparedStatement  *pstmt;


		pstmt = con->prepareStatement(sqlquary);
		for(int i=0;i<=2;i++)
			pstmt->setString(i+1,str[i]);
		/*
		pstmt->setString(1, str[0]);
		pstmt->setString(2,str[1]	);
		pstmt->setString(3,str[2]	);
		*/
		pstmt->setInt(4,	in[0]	);
		pstmt->setInt(5,	in[1]	);
		pstmt->setInt(6, in[2]);
		pstmt->setInt(7, in[3]);

		pstmt->execute();

		gotoxy(20,18); cout << "Saved Successfully! ";
		delete pstmt;
		//delete res;
		delete stmt;
		delete con;
		_getch();
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
		system("pause");
	}

}


void update(string sqlquary, string str[], int in[])
{
	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;

		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		stmt = con->createStatement();

		sql::PreparedStatement  *pstmt;


		pstmt = con->prepareStatement(sqlquary);

		pstmt->setString(1, str[0]);
		pstmt->setString(2, str[1]);
		pstmt->setString(3, str[2]);
		pstmt->setInt(4,	in[0]);
		pstmt->setInt(5,	in[1]);
		pstmt->setInt(6, in[2]);

		pstmt->executeUpdate();

		delete pstmt;
		delete stmt;
		delete con;
		system("pause");
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		//system("cls");
		cout << "Error in SQL database";
	}
}


void del(string sqlquary,int code)
{
	try
	{
		sql::Driver *driver;
		sql::Connection *con;
		sql::Statement *stmt;
		//sql::ResultSet *res;

		driver = get_driver_instance();
		con = driver->connect("tcp://127.0.0.1:3306", "root", "");
		con->setSchema("library");
		stmt = con->createStatement();

		sql::PreparedStatement  *pstmt;


		pstmt = con->prepareStatement(sqlquary);

		pstmt->setInt(1, code);

		pstmt->execute();

		delete pstmt;
		//delete res;
		delete stmt;
		delete con;
		system("pause");
	}
	catch (sql::SQLException &e)
	{
		cout << "# ERR: SQLException in " << __FILE__;
		cout << "(" << __FUNCTION__ << ") on line " << __LINE__ << endl;
		cout << "# ERR: " << e.what();
		cout << " (MySQL error code: " << e.getErrorCode();
		cout << ", SQLState: " << e.getSQLState() << " )" << endl;
		system("cls");
		cout << "Error in SQL database";
		system("pause");
	}
}


//welcome screen
void welcomeScreen()
{
	system("cls");
	system("color 2");
	gotoxy(20, 9);	cout << "Welcome to Library Management System";
	gotoxy(30, 15); cout << "Loading...";
	for (int i = 0; i <= 100; i += 1)
	{
		gotoxy(40, 15); cout << i << "%";
		gotoxy(44, 15); 
		if(i%3==0) cout << "\\";
		else if((i%5==0)) cout << "|";
		else if(i%4==0) cout << "/";
		else cout << "-";
		Sleep(50);
	}
	//Sleep(2000);
}

//bye screen

void byeScreen()
{
	system("cls");
	gotoxy(20, 9);
	cout << "Thank you for using this software!";
	Sleep(1500);
}


int main()
{
	//SetTextColor(GetStdHandle(STD_OUTPUT_HANDLE),RGB(0,255,0));
	system("title \"Library Management System\"");
	while (1)
	{
		system("cls");
		system("color 2");
		char ch;
		string un, pw;
		gotoxy(22, 9);	cout << "Username: ";
		cin >> un;
		gotoxy(22, 10);	cout << "Password: ";
		ch = _getch();
		while (ch != 13) //character 13 is enter
		{
			pw.push_back(ch);
			cout << '*';
			ch = _getch();
		}
		if (un=="admin" && pw=="password")
		{
			break;
		}
		else
		{
			system("cls");
			system("color 4");
			gotoxy(20, 10);	cout << "Wrong username or password..!";
			_getch();
		}
	}
	welcomeScreen();
	while (!stop)
	{
			mainMenu();
		//fflush(stdin);
	}
	byeScreen();
	return 0;
}